let listOfSkills = [
    'Flutter',
    'Dart',
    'JavaScript',
    'Node js',
    'Firebase',
    'MongoDB',
    'PostgreSql',
    'CSS',
    'React',
    'Bootstrap',
    'Java',
    'Mocha',
    'HandleBars',
    'Travis CI',
    'Jest',
    'Redis',
    'Docker'
]

function dataFoctory() {

    const skills = () => listOfSkills;

    return {
        skills
    }


}








